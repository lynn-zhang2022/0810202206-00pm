from flask_mail import Message

